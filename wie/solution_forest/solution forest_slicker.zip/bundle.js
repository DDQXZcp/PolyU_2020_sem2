$(document).ready(function(){
  $('.slicker').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1
  }); 
});